module.exports = {
    APPLICATION_ID: "4ZtOr8dH39yTjWac6Yd28N0ijgEcFAQsy3v0WTMg",
    JAVASCRIPT_KEY: "aaYlMdcj2Z7VmX4YT7QOspEIzuH5ufEdfE8U3azb",
    SERVER_URL: "https://parseapi.back4app.com/"
  };