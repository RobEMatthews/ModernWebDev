import React from "react";
import MainModule from "./Main/Main.js";
import FavoritesModule from "./Favorites/Favorites.js";


const Components = () => {
  return (
    <><div>
        <MainModule />
      </div>

       <div>
        <FavoritesModule />
      </div></> 
  );
};

export default Components;